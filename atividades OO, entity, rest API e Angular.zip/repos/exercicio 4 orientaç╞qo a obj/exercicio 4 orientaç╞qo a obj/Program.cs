﻿namespace exercicio_4_orientaçãqo_a_obj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pessoa l1 = new Pessoa();
            Console.WriteLine("Digite o nome da pessoa:");
            l1.nome = Console.ReadLine();
            Console.WriteLine("Digite o cpf:");
            l1.cpf = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o rg:");
            l1.rg = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o nascimento:");
            l1.nascimento = int.Parse(Console.ReadLine());

            Console.WriteLine(l1.nome);
            Console.WriteLine(l1.cpf);
            Console.WriteLine(l1.rg);
            Console.WriteLine(l1.nascimento);
        }
    }
}