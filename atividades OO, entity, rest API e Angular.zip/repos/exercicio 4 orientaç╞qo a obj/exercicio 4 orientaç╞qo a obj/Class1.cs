﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_4_orientaçãqo_a_obj
{
    internal class Pessoa
    {
        public int cpf;
        public int rg;
        public string nome;
        public int nascimento;
    }
}
