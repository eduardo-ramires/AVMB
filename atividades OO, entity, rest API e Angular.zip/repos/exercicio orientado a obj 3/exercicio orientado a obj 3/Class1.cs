﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_orientado_a_obj_3
{
    internal class Livro
    {
        public string titulo;
        public int isbn;
        public string autor;
        public string categoria;
        public int num_paginas;
    }
}
