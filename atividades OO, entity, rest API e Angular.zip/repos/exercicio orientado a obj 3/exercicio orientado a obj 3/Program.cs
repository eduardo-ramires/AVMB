﻿namespace exercicio_orientado_a_obj_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Livro l1 = new Livro();
            Console.WriteLine("Digite o titulo:");
            l1.titulo = Console.ReadLine();
            Console.WriteLine("Digite a isbn:");
            l1.isbn = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o numero de paginas:");
            l1.num_paginas= int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o nome do autor");
            l1.autor = Console.ReadLine();
            Console.WriteLine("Digite a categoria:");
            l1.categoria = Console.ReadLine();

            Console.WriteLine( l1.titulo);
            Console.WriteLine(l1.isbn);
            Console.WriteLine(l1.num_paginas);
            Console.WriteLine(l1.autor);
            Console.WriteLine(l1.categoria);
        }
    }
}