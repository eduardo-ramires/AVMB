﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace atividade_04_OO
{
    internal class Pessoa
    {
        public string nome;
        public string cpf;
        public string sexo;
        public string nacionalidade;
        public string dataNascimento;
        public string rg;
        public string endereco;

        public Pessoa()
        {

        }


        public Pessoa(string nome, string cpf, string sexo, string nacionalidade, string dataNascimento, string rg, string endereco)
        {
            this.nome = nome;
            this.rg = rg;
            this.cpf = cpf;
            this.endereco = endereco;
            this.nacionalidade = nacionalidade;
            this.dataNascimento = dataNascimento;
            this.sexo = sexo;
        }


    } 
}
