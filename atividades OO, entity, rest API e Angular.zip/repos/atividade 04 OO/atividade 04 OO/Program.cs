﻿namespace atividade_04_OO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Pessoa ps = new Pessoa();

            Console.WriteLine("Novo cadastro:");
            Console.WriteLine("Digite o nome do aluno");
            ps.nome = Console.ReadLine();
            Console.WriteLine("Digite o cpf do aluno");
            ps.cpf = Console.ReadLine();
            Console.WriteLine("Digite o rg do aluno");
            ps.rg = Console.ReadLine();
            Console.WriteLine("Digite a nacionalidade do aluno");
            ps.nacionalidade = Console.ReadLine();
            Console.WriteLine("Digite o sexo do aluno");
            ps.sexo = Console.ReadLine();
            Console.WriteLine("Digite o endereço do aluno");
            ps.endereco = Console.ReadLine();
            Console.WriteLine("Digite a data de nascimento do aluno");
            ps.dataNascimento = Console.ReadLine();

            Pessoa p1 = new Pessoa("ricardo", "123", "M", "brasil", "12345", "rs", "fdfdsfdsf");

            Console.WriteLine("Nome do aluno: " + ps.nome);
            Console.WriteLine("CPF do aluno: " + ps.cpf);
            Console.WriteLine("RG do aluno: " + ps.rg);
            Console.WriteLine("Nascionalidade do aluno: " + ps.nacionalidade);
            Console.WriteLine("Data de nascimento do aluno: " + ps.dataNascimento);
            Console.WriteLine("Endereço do aluno: " + ps.endereco);
            Console.WriteLine("Sexo do aluno: " + ps.sexo);
        }
    }
}