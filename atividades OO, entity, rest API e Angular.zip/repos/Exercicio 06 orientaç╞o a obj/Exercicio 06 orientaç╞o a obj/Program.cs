﻿namespace Exercicio_06_orientação_a_obj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Motor mt = new Motor();
            mt.motores("ford",  "maquina", 100);
            Console.WriteLine(mt.retorna());
        }
    }
}