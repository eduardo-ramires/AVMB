﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_06_orientação_a_obj
{
    internal class Motor
    {
        private string nomeFabricante;
        private string tipo;
        private int potencia;

        public void motores(string nomeFabricante, string tipo, int potencia)
        {
            this.nomeFabricante = nomeFabricante;
            this.tipo = tipo;
            this.potencia = potencia;
        }

        public string retorna()
        {
            return nomeFabricante + " - " + tipo + " - " + potencia;
        }
    }
}
