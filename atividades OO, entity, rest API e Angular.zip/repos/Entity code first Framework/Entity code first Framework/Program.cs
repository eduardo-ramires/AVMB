﻿using Entity_code_first_Framework.DataModels;
using Microsoft.EntityFrameworkCore;
using System.Net.Http.Headers;

namespace Entity_code_first_Framework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite\n" +
                "1 Para criar uma pessoa\n" +
                "2 para alterar o nome da pessoa\n" +
                "3 para inserir um email\n" +
                "4 para exluir uma pessoa\n" +
                "5 para consultar tudo\n" +
                "6 para consultar pelo ID\n");

            int op = int.Parse(Console.ReadLine());
            contexto contexto = new contexto();

            switch (op)
            {
                case 1:
                    try
                    {
                        Console.WriteLine("Inserir o nome da pessoa");
                        Pessoa p = new Pessoa();
                        p.nome = Console.ReadLine();

                        Console.WriteLine("Informe um E-email:");
                        string emailTemp = Console.ReadLine();

                        p.Emails = new List<Email>()
                        {
                            new Email()
                            {
                                email = emailTemp
                            }
                        };

                        contexto.Pessoas.Add(p);
                        contexto.SaveChanges();

                        Console.WriteLine("Pessoa inserida com sucesso");

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 2:
                    try
                    {
                        Console.WriteLine("Informe o ID da pessoa");
                        int id = int.Parse(Console.ReadLine());

                        Pessoa pAlt = contexto.Pessoas.Find(id);
                        Console.WriteLine("Informe o nome correto:");
                        pAlt.nome = Console.ReadLine();

                        contexto.Pessoas.Update(pAlt);
                        contexto.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 3:
                    try
                    {
                        Console.WriteLine("Infome o ID da pessoa:");
                        int id = int.Parse(Console.ReadLine());
                        Pessoa p = contexto.Pessoas.Find(id);

                        Console.WriteLine("Informe o novo e-mail:");
                        string emailTemp = Console.ReadLine();

                        p.Emails = new List<Email>() {
                            new Email()
                            {
                                email = emailTemp
                            }
                        };

                        contexto.Pessoas.Update(p);
                        contexto.SaveChanges();
                        Console.WriteLine("E-mail add com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 4:
                    try
                    {
                        Console.WriteLine("Infome o ID da pessoa:");
                        int id = int.Parse(Console.ReadLine());
                        Pessoa p = contexto.Pessoas.Find(id);

                        Console.WriteLine("Confirmar a exclusão de: " + p.nome);
                        Console.WriteLine("E dos seus e-mail:");

                        foreach (Email item in p.Emails)
                        {
                            Console.WriteLine(  "\t" + item.email);
                        }

                        Console.WriteLine("Digite 1 para excluir ou qualquer outra tecla para cancelar a exclusão:");
                        if (int.Parse(Console.ReadLine()) == 1)
                        {
                            contexto.Pessoas.Remove(p);
                            contexto.SaveChanges();
                            Console.WriteLine("Exclusão concluida");
                        }
                        else
                        {
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 5:
                    try
                    {
                        List<Pessoa> lista = (from Pessoa p in contexto.Pessoas
                                              select p).Include(pes =>pes.Emails).ToList<Pessoa>();

                        foreach(Pessoa item in lista)
                        {
                            Console.WriteLine(item.nome);
                            foreach(Email itemE in item.Emails)
                            {
                                Console.WriteLine("\t" + itemE.email);
                            }
                            Console.WriteLine();
                        }
                        Console.WriteLine("Concluido");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 6:
                    try
                    {
                        Console.WriteLine("Informe o |Id da pessoa");
                        int idPessoa = int.Parse(Console.ReadLine());
                        Pessoa pessoa = contexto.Pessoas
                            .Include(p => p.Emails)
                            .FirstOrDefault(x => x.Id == idPessoa);
                        Console.WriteLine(pessoa.nome);

                        if (pessoa.Emails != null)
                        {
                            foreach(Email item in pessoa.Emails)
                            {
                                Console.WriteLine(" " + item.email);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
            }
        }
    }
}