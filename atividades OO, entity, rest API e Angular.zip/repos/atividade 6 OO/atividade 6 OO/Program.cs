﻿namespace atividade_6_OO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nome, cpf, rg, sexo, dataNascimento, endereco, nacionalidade;

            Console.WriteLine("Novo cadastro:");
            Console.WriteLine("Digite o nome do aluno");
            nome = Console.ReadLine();
            Console.WriteLine("Digite o cpf do aluno");
            cpf = Console.ReadLine();
            Console.WriteLine("Digite o rg do aluno");
            rg = Console.ReadLine();
            Console.WriteLine("Digite a nacionalidade do aluno");
            nacionalidade = Console.ReadLine();
            Console.WriteLine("Digite o sexo do aluno");
            sexo = Console.ReadLine();
            Console.WriteLine("Digite o endereço do aluno");
            endereco = Console.ReadLine();
            Console.WriteLine("Digite a data de nascimento do aluno");
            dataNascimento = Console.ReadLine();

            Aluno al = new Aluno(nome, cpf, sexo, nacionalidade, dataNascimento, rg, endereco);

            Console.WriteLine("Nome do aluno: " +al.nome);
            Console.WriteLine("CPF do aluno: " + al.cpf);
            Console.WriteLine("RG do aluno: " + al.rg);
            Console.WriteLine("Nascionalidade do aluno: " + al.nacionalidade);
            Console.WriteLine("Data de nascimento do aluno: " + al.dataNascimento);
            Console.WriteLine("Endereço do aluno: " + al.endereco);
            Console.WriteLine("Sexo do aluno: " + al.sexo);
        }
    }
}