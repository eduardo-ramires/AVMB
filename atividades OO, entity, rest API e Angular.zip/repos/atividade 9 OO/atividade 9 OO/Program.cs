﻿using System.Runtime.CompilerServices;

namespace atividade_9_OO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nomeFabricante, tipo;
            int potencia;

            Console.WriteLine("Digite o nome do fabricante");
            nomeFabricante = Console.ReadLine();
            Console.WriteLine("Digite a potencia do carro");
            potencia = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o tipo do carro");
            tipo = Console.ReadLine();


            Carro cr = new Carro();
            cr.setnomeFabricante(nomeFabricante);
            cr.setpotencia(potencia);
            cr.settipo(tipo);


            cr.imprimeDados();
        }
    }
}