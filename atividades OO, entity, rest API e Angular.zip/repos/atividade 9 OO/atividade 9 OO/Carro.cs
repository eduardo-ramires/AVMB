﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atividade_9_OO
{
    internal class Carro
    {
        private string nomeFabricante;
        private int potencia;
        private string tipo;

        public void setnomeFabricante(string nomeFabricante)
        {
            this.nomeFabricante = nomeFabricante;
        }

        public string getnomeFabricante()
        {
            return nomeFabricante;
        }

        public void imprimeDados(){
            Console.WriteLine(potencia + "-" +nomeFabricante +"-" + tipo);
        }




        public void setpotencia(int potencia)
        {
            this.potencia = potencia;
        }
        public int getpotencia()
        {
            return potencia;
        }




        public void settipo(string tipo)
        {
            this.tipo = tipo;
        }
        public string gettipo()
        {
            return tipo;
        }
    }
}
