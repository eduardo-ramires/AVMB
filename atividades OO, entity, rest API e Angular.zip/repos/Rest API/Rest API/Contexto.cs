﻿

using Microsoft.EntityFrameworkCore;
using Rest_API.DataModels;
using System;
using System.Collections.Generic;
using System.Configuration;

namespace Rest_API
{
    public class Contexto : DbContext
    {
        public DbSet<Pessoa> Pessoas { get; set; }

        public Contexto()
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            ConnectionStringSettings settings = System.Configuration.ConfigurationManager.ConnectionStrings["EntityPostgresql"];
            string retorno = "";

            if (settings != null)
                retorno = settings.ConnectionString;

            optionsBuilder.UseNpgsql(retorno);
            optionsBuilder.UseLazyLoadingProxies(true);
        }

    }
}
