﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rest_API.DataModels
{
    public class Pessoa
    {

        public int Id { get; set; }
        public string nome { get; set; }
    }
}
