using Microsoft.AspNetCore.Mvc;

namespace Rest_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ApiController : ControllerBase
    {
        [HttpGet("hello")]

        public string HelloWord()
        {
            return "Hello word API Net6";
        }

        [HttpGet("nome")]

        public string nome()
        {
            return "Eduardo GR";
        }



        [HttpGet("idade")]

        public string idade()
        {
            return "17";
        }




        [HttpPost("recebeNome")]
        public string recebeNome([FromBody] string nome)
        {
            return nome;
        }



        [HttpPost("recebeNomeIdade/{idade}")]
        public string recebeNomeIdade([FromBody] string nome, [FromRoute] int idade)
        {
            //return idade.ToString();
            if (idade >= 18)
            {
                return nome + " � maior de idade";
            }
            else
            {
                return nome + " � menor de idade";
            }

        }

    }
}