﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Rest_API.DataModels;

namespace Rest_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class entityController : ControllerBase
    {
        [HttpGet]
        [Route("pessoas")]

        

            public async Task<IActionResult> GetActionAsync(
            [FromServices] Contexto contexto
            )
        {
            var pessoas = await contexto
                .Pessoas
                .AsNoTracking()
                .ToListAsync();


            return pessoas == null ? NotFound() : Ok(pessoas);

        }

        [HttpGet]
        [Route("pessoas/{id}")]

        public async Task<IActionResult> GetActionAsync(
            [FromServices] Contexto contexto,
            [FromRoute] int id
            )
        {
            var pessoas = await contexto
                .Pessoas
                .FirstOrDefaultAsync(p => p.Id == id);


            return pessoas == null ? NotFound() : Ok(pessoas);

        }

        [HttpPost]
        [Route("pessoas")]

        public async Task<IActionResult> GetActionAsync(
            [FromServices] Contexto contexto,
            [FromBody] Pessoa pessoa
            )
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            try
            {
                await contexto.Pessoas.AddAsync(pessoa);
                await contexto.SaveChangesAsync();
                return Created($"api/pessoas/{pessoa.Id}", pessoa);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut]
        [Route("pessoas/{id}")]

        public async Task<IActionResult> PutAsync
            (
            [FromServices] Contexto contexto,
            [FromBody] Pessoa pessoa,
            [FromRoute] int id
            )
        {
            var p = await contexto.Pessoas
                .FirstOrDefaultAsync(x => x.Id == id);

            if(p == null) return NotFound("Pessoa não encontrada");

            try
            {
                p.nome = pessoa.nome;

                contexto.Pessoas.Update(p);
                await contexto.SaveChangesAsync();
                return Ok(p);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete]
        [Route("pessoas/{id}")]

        public async Task<IActionResult> DeleteAsync(
            [FromServices] Contexto contexto,
            [FromRoute] int id)
        {
            var p = await contexto.Pessoas.FirstOrDefaultAsync(x => x.Id == id);

            if (p == null) return BadRequest("Pessoa não encontrada");

            try
            {
                contexto.Pessoas.Remove(p);
                await contexto.SaveChangesAsync();

                return Ok();
            }

            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
