﻿namespace atividade_03_OO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Personagem ps = new Personagem();
            ps.personagem("Richard", " desenvolvedor de units", "pedra", "goleiro", "masculino");
            Console.WriteLine(ps.retorna());
        }
    }
}