﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atividade_03_OO
{
    internal class Personagem
    {
        public string nome;
        public string descricao;
        public string item_coletado;
        public string posicao;
        public string sexo;


        public void personagem(string nome, string descricao, string item_coletado,string posicao, string sexo)
        {
            this.nome = nome;
            this.descricao = descricao;
            this.item_coletado = item_coletado;
            this.posicao = posicao;
            this.sexo = sexo;
        }

        public string retorna()
        {
            return "o personagem " + nome + ", " + sexo + ", de descrição " + descricao + " coletou o item " + item_coletado + " e esta na posição " + posicao;
        }
    }
}
