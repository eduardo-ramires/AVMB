﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_07_aula_orientação_a_obj
{
    internal class Carro
    {
        private string modelo;
        private string cor;
        private int ano;
        private string marca;
        private string chassi;
        private string proprietario;
        private int vel_max;
        private int vel_atual;
        private int num_portas;
        private bool teto_solar;
        private int num_marcha;
        private bool cambio;
        private int vol_combustivel;


        public void aumentaVelocidade(int vel_atual)
        {
            if (vel_atual < vel_max){
                this.vel_atual = vel_atual++;
            } 
        }
    }
}