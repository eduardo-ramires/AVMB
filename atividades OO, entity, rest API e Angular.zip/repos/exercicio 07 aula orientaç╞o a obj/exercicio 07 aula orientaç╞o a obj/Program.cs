﻿namespace exercicio_07_aula_orientação_a_obj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Carro car = new Carro();
        }
    }
}