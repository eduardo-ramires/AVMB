﻿using EntityFramework_exercio_1.DataModels;
using Microsoft.EntityFrameworkCore;

namespace EntityFramework_exercio_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite\n" +
               "1 Para criar um aluno\n" +
               "2 para alterar o nome da pessoa\n" +
               "3 para inserir um email\n" +
               "4 para exluir uma pessoa\n" +
               "5 para consultar tudo\n" +
               "6 para consultar pelo ID\n");

            int op = int.Parse(Console.ReadLine());
            contexto contexto = new contexto();

            switch (op)
            {
                case 1:
                    try
                    {
                        Console.WriteLine("Inserir o nome do aluno");
                        Aluno al = new Aluno();
                        al.nome = Console.ReadLine();

                        Console.WriteLine("Informe um Curso:");
                        string cursoAdd = Console.ReadLine();

                        al.Cursos = new List<Curso>()
                        {
                            new Curso()
                            {
                                nome = cursoAdd
                            }
                        };

                        contexto.Alunos.Add(al);
                        contexto.SaveChanges();

                        Console.WriteLine("Aluno inserida com sucesso");

                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 2:
                    try
                    {
                        Console.WriteLine("Informe o id do aluno");
                        int id = int.Parse(Console.ReadLine());

                        Aluno pAlt = contexto.Alunos.Find(id);
                        Console.WriteLine("Informe o nome correto:");
                        pAlt.nome = Console.ReadLine();

                        contexto.Alunos.Update(pAlt);
                        contexto.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 3:
                    try
                    {
                        Console.WriteLine("Informe o id do aluno");
                        int id = int.Parse(Console.ReadLine());

                        Aluno p = contexto.Alunos.Find(id);

                        Console.WriteLine("Informe o novo curso:");
                        string cursoNew = Console.ReadLine();

                        p.Cursos = new List<Curso>() {
                            new Curso()
                            {
                                nome = cursoNew
                            }
                        };

                        contexto.Alunos.Update(p);
                        contexto.SaveChanges();
                        Console.WriteLine("Curso add com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 4:
                    try
                    {
                        Console.WriteLine("Informe o id do aluno");
                        int id = int.Parse(Console.ReadLine());

                        Aluno p = contexto.Alunos.Find(id);

                        Console.WriteLine("Confirmar a exclusão de: " + p.nome);
                        Console.WriteLine("E dos seus cursos:");

                        foreach (Curso item in p.Cursos)
                        {
                            Console.WriteLine("\t" + item.nome);
                        }

                        Console.WriteLine("Digite 1 para excluir ou qualquer outra tecla para cancelar a exclusão:");
                        if (int.Parse(Console.ReadLine()) == 1)
                        {
                            contexto.Alunos.Remove(p);
                            contexto.SaveChanges();
                            Console.WriteLine("Exclusão concluida");
                        }
                        else
                        {
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 5:
                    try
                    {
                        List<Aluno> lista = (from Aluno p in contexto.Alunos
                                              select p).Include(pes => pes.Cursos).ToList<Aluno>();

                        foreach (Aluno item in lista)
                        {
                            Console.WriteLine(item.nome);
                            foreach (Curso itemE in item.Cursos)
                            {
                                Console.WriteLine("\t" + itemE.nome);
                            }
                            Console.WriteLine();
                        }
                        Console.WriteLine("Concluido");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case 6:
                    try
                    {
                        Console.WriteLine("Informe o |Id da pessoa");
                        int idPessoa = int.Parse(Console.ReadLine());
                        Aluno pessoa = contexto.Alunos
                            .Include(p => p.Cursos)
                            .FirstOrDefault(x => x.Id == idPessoa);
                        Console.WriteLine(pessoa.nome);

                        if (pessoa.Cursos != null)
                        {
                            foreach (Curso item in pessoa.Cursos)
                            {
                                Console.WriteLine(" " + item.nome);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
            }
        }
    }
}