﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFramework_exercio_1.DataModels
{
    public class Aluno
    {
        public int Id { get; set; }
        public string nome { get; set; }

        public virtual ICollection<Curso> Cursos { get; set; }
    }
}
