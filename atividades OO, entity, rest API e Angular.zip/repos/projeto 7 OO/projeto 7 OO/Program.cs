﻿namespace projeto_7_OO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nome, descricao, posicao, sexo;
            int item_coletado;
            Console.WriteLine("Digite o nome do personagem:");
            nome = Console.ReadLine();
            Console.WriteLine("Digite o sexo do personagem:");
            sexo = Console.ReadLine();
            Console.WriteLine("Digite a descrição do personagem:");
            descricao = Console.ReadLine();
            Console.WriteLine("Digite a posição do personagem:");
            posicao = Console.ReadLine();
            Console.WriteLine("Digite a quantidade de itens coletados:");
            item_coletado = int.Parse(Console.ReadLine());

            Personagem p1 = new Personagem(nome, descricao, item_coletado, posicao, sexo);

            Console.WriteLine("Nome do personagem: " + p1.nome);
            Console.WriteLine("Sexo do personagem: " + p1.sexo);
            Console.WriteLine("Descrição do personagem: " + p1.descricao);
            Console.WriteLine("Posição do personagem: " + p1.posicao);
            Console.WriteLine("Quantidade de itens coletados: " + p1.item_coletado);
        }
    }
}