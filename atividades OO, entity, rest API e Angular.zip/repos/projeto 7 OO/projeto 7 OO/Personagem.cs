﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projeto_7_OO
{
    internal class Personagem
    {
        public string nome;
        public string descricao;
        public int item_coletado;
        public string posicao;
        public string sexo;


        public Personagem(string nome, string descricao, int item_coletado, string posicao, string sexo)
        {
            this.nome = nome;
            this.descricao = descricao;
            this.item_coletado = item_coletado;
            this.posicao = posicao;
            this.sexo = sexo;
        }
    }
}
