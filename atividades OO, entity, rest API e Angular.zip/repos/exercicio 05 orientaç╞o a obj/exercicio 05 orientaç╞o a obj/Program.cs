﻿namespace exercicio_05_orientação_a_obj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Disciplina dc = new Disciplina("brasil", 6);
            Console.WriteLine(dc.nome_disciplina + "\n" +  dc.carga_horaria);

        }
    }
}