﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio_05_orientação_a_obj
{
    internal class Disciplina
    {
        public string nome_disciplina;
        public int carga_horaria;
        public Disciplina(string disciplina, int carga)
        {
            this.nome_disciplina = disciplina;
            this.carga_horaria = carga;
        }
    }
}
