﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace orientacao_A_Obj
{
    internal class lampada
    {

        public int ligada;
        public double potencia;
        public void ligar()
        {
            ligada = 1;
        }

        public void meiaLuz()
        {
            ligada = 2;
        }

        public void desligar()
        {
            ligada = 3;
        }

        public int estaLigada()
        {
            return ligada;
        }

    }
}
