﻿namespace orientacao_A_Obj
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("Testando");
            lampada li = new lampada();
            li.potencia = 200;
            Console.WriteLine(li.potencia);
            li.ligar();
            Console.WriteLine(li.ligada);
            li.meiaLuz();
            Console.WriteLine(li.ligada);
            li.desligar();
            Console.WriteLine(li.ligada);
            */

            
        }
    }
}