﻿namespace atividade_01_OO
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int resp = 1;


            Tv tv = new Tv();

            Console.WriteLine("Digite 0 para ligar a TV e 1 para desligar");
            resp = int.Parse (Console.ReadLine());

            if (resp == 0)
            {
                tv.liga();
            }
            else
            {
                tv.desliga();
            }

            tv.registro_tv("philips", "2002", "novo", "98649");
            Console.WriteLine(tv.retorno_tv());


        }
    }
}