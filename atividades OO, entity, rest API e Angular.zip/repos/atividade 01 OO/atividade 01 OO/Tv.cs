﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atividade_01_OO
{
    internal class Tv
    {
        public string marca;
        public string ano;
        public string modelo;
        public string num_serie;
        public bool ligar;

        public void registro_tv(string marca, string ano, string modelo, string num_serie)
        {
            this.marca = marca;
            this.ano = ano;
            this.modelo = modelo;
            this.num_serie = num_serie;
        }
        public void aumentarVol()
        {
            
        }
        public void liga()
        {
            if (ligar == true){
                Console.WriteLine("já esta ligada");
            }
            else
            {
                ligar = true;
                Console.WriteLine("Ligando");
            }
        }

        public void desliga()
        {
            if (ligar == true)
            {
                ligar = false;
                Console.WriteLine("Desligando");
            }
            else
            {
                Console.WriteLine("Ja esta desligada");
            }
        }

        public string retorno_tv()
        {
            return marca + "-" + ano + "-" + modelo + "-" + num_serie;
        }
    }
}
