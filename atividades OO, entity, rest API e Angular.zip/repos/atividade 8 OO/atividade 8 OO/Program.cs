﻿namespace atividade_8_OO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nome, cpf, rg, sexo, dataNascimento, endereco, nacionalidade;

            Console.WriteLine("Cadastro de funcionario:");
            Console.WriteLine("Digite o nome do Funcionario");
            nome = Console.ReadLine();
            Console.WriteLine("Digite o cpf do Funcionario");
            cpf = Console.ReadLine();
            Console.WriteLine("Digite o rg do Funcionario");
            rg = Console.ReadLine();
            Console.WriteLine("Digite a nacionalidade do Funcionario");
            nacionalidade = Console.ReadLine();
            Console.WriteLine("Digite o sexo do Funcionario");
            sexo = Console.ReadLine();
            Console.WriteLine("Digite o endereço do Funcionario");
            endereco = Console.ReadLine();
            Console.WriteLine("Digite a data de nascimento do Funcionario");
            dataNascimento = Console.ReadLine();

            Funcionarios fc = new Funcionarios(nome, cpf, sexo, nacionalidade, dataNascimento, rg, endereco);

            Console.WriteLine("Nome do aluno: " + fc.nome);
            Console.WriteLine("CPF do aluno: " + fc.cpf);
            Console.WriteLine("RG do aluno: " + fc.rg);
            Console.WriteLine("Nascionalidade do aluno: " + fc.nacionalidade);
            Console.WriteLine("Data de nascimento do aluno: " + fc.dataNascimento);
            Console.WriteLine("Endereço do aluno: " + fc.endereco);
            Console.WriteLine("Sexo do aluno: " + fc.sexo);
        }
    }
}