﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula_orientada_a_obj_parte_02
{
    class Cachorro : Animal
    {
        public override void fazerBarulho()
        {
            Console.WriteLine("Au-Au!");
        }
    }
}
