﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atividade_5_OO
{
    internal class Livro
    {
        public string titulo;
        public int isbn;
        public string autor;
        public string categoria;
        public int num_paginas;

        public Livro(string titulo, int isbn, string autor, string categoria, int num_paginas)
        {
            this.titulo = titulo;
            this.isbn = isbn;
            this.autor = autor;
            this.categoria = categoria;
            this.num_paginas = num_paginas;
        }
    }
}
