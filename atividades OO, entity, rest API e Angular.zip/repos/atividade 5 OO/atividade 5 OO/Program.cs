﻿using System.Linq.Expressions;

namespace atividade_5_OO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string titulo, autor, categoria;
            int num_paginas, isbn;
            Console.WriteLine("Digite o titulo:");
            titulo = Console.ReadLine();
            Console.WriteLine("Digite a isbn:");
            isbn = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o numero de paginas:");
            num_paginas = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o nome do autor");
            autor = Console.ReadLine();
            Console.WriteLine("Digite a categoria:");
            categoria = Console.ReadLine();

            Livro lv = new Livro(titulo, num_paginas, autor, categoria, isbn);
            Console.WriteLine(lv.titulo + "-" + lv.num_paginas + "-" + lv.autor + "-" + lv.categoria + "-" + lv.isbn);
        }
    }
}